@extends('backend.app')

@section('title')
    Dashboard
@endsection

@section('location')
    Dashboard    
@endsection

@section('content')
<div class="container">
</div>
@endsection
